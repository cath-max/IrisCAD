"""OCP-native core class definitions for the SimpleCAD API."""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple, Union, cast

import numpy as np
from OCP.TopAbs import TopAbs_COMPOUND, TopAbs_EDGE, TopAbs_FACE, TopAbs_SOLID, TopAbs_VERTEX, TopAbs_WIRE
from OCP.TopoDS import TopoDS, TopoDS_Shape

from ._vendor_warning_filters import suppress_vendor_deprecation_warnings
from .errors import raise_harness_error
from .kernel.ocp_cast import as_compound, as_edge, as_face, as_solid, as_vertex, as_wire, shape_type_name
from .kernel.ocp_booleans import solids_of
from .kernel.ocp_properties import Vec3, center_of_mass, face_normal_at, linear_length, surface_area, volume
from .kernel.ocp_topology import edges_of, faces_of, inner_wires_of, is_wire_closed, outer_wire_of, vertex_point, vertices_of
from .tagging import DEFAULT_TAG_POLICY, normalize_tag

suppress_vendor_deprecation_warnings()


def _safe_shape_hash(shape: Any) -> int:
    try:
        return int(shape.HashCode(1000000))
    except Exception:
        return int(hash(shape))


@dataclass
class _TopoEntity:
    kind: str
    topo_id: str
    representative: Any
    tags: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)
    runtime: Dict[str, Any] = field(default_factory=dict)
    wrappers: List[Any] = field(default_factory=list)
    incident_face_ids: Set[str] = field(default_factory=set)
    incident_edge_ids: Set[str] = field(default_factory=set)


class _TopologyEntityCache:
    def __init__(self) -> None:
        self._buckets: Dict[Tuple[str, int], List[_TopoEntity]] = {}
        self._counters: Dict[str, int] = {}
        self._entities_by_id: Dict[str, _TopoEntity] = {}

    def get(self, kind: str, shape: Any) -> _TopoEntity:
        key = (kind, _safe_shape_hash(shape))
        bucket = self._buckets.setdefault(key, [])
        for entity in bucket:
            try:
                if entity.representative.IsSame(shape):
                    return entity
            except Exception:
                pass

        idx = self._counters.get(kind, 0)
        self._counters[kind] = idx + 1
        entity = _TopoEntity(kind=kind, topo_id=f"{kind}_{idx}", representative=shape)
        bucket.append(entity)
        self._entities_by_id[entity.topo_id] = entity
        return entity

    def wrappers_for(self, topo_id: str) -> List[Any]:
        entity = self._entities_by_id.get(topo_id)
        return list(entity.wrappers) if entity is not None else []

    def entities(self, kind: Optional[str] = None) -> List[_TopoEntity]:
        if kind is None:
            return list(self._entities_by_id.values())
        return [entity for entity in self._entities_by_id.values() if entity.kind == kind]


class CoordinateSystem:
    """Three-dimensional coordinate system.

    SimpleCAD uses a right-handed Z-up coordinate system with the origin at
    (0, 0, 0): X forward, Y right, Z up.
    """

    def __init__(
        self,
        origin: Tuple[float, float, float] = (0, 0, 0),
        x_axis: Tuple[float, float, float] = (1, 0, 0),
        y_axis: Tuple[float, float, float] = (0, 1, 0),
    ):
        try:
            self.origin = np.array(origin, dtype=float)
            self.x_axis = self._normalize(x_axis)
            self.y_axis = self._normalize(y_axis)
            self.z_axis = self._normalize(np.cross(self.x_axis, self.y_axis))
        except Exception as e:
            raise_harness_error(
                operation="CoordinateSystem.__init__",
                what_happened="Failed to create a coordinate system.",
                possible_causes=[
                    "One of the origin or axis values is not a valid 3D numeric vector.",
                    "One of the axis vectors is zero-length or cannot be normalized.",
                    "The axis inputs are malformed or contain non-numeric values.",
                ],
                how_to_fix=[
                    "Pass origin, x_axis, and y_axis as 3-element numeric tuples or arrays.",
                    "Make sure x_axis and y_axis are non-zero vectors.",
                    "If you build axes dynamically, print the vectors before constructing the coordinate system.",
                ],
                error=e,
            )

    def _normalize(self, vector) -> np.ndarray:
        v = np.array(vector, dtype=float)
        norm = np.linalg.norm(v)
        if norm == 0:
            raise_harness_error(
                operation="CoordinateSystem._normalize",
                what_happened="A zero-length vector cannot be normalized.",
                possible_causes=[
                    "The input vector is exactly (0, 0, 0).",
                    "The input values collapsed to zero after numeric conversion.",
                ],
                how_to_fix=[
                    "Provide a non-zero direction vector.",
                    "Check upstream calculations that produce this vector.",
                ],
                technical_details=f"vector={tuple(v.tolist())}",
            )
        return v / norm

    def transform_point(self, point: np.ndarray) -> np.ndarray:
        try:
            local_point = np.asarray(point, dtype=float)
            if local_point.shape != (3,):
                raise_harness_error(
                    operation="CoordinateSystem.transform_point",
                    what_happened="The point could not be interpreted as a 3D coordinate.",
                    possible_causes=[
                        "The point does not contain exactly three numeric components.",
                        "The point contains NaN or non-numeric values.",
                    ],
                    how_to_fix=[
                        "Pass the point as a 3-element tuple, list, or NumPy array.",
                        "Validate the point values before calling transform_point().",
                    ],
                    technical_details=f"point_shape={local_point.shape}",
                )
            if not np.all(np.isfinite(local_point)):
                raise_harness_error(
                    operation="CoordinateSystem.transform_point",
                    what_happened="The point contains non-finite numeric values.",
                    possible_causes=[
                        "A previous computation produced NaN or infinity.",
                        "The point was assembled from invalid expression results.",
                    ],
                    how_to_fix=[
                        "Inspect the upstream values used to build the point.",
                        "Replace NaN or infinity with finite numeric coordinates before calling this API.",
                    ],
                    technical_details=f"point={tuple(local_point.tolist())}",
                )
            return (
                self.origin
                + local_point[0] * self.x_axis
                + local_point[1] * self.y_axis
                + local_point[2] * self.z_axis
            )
        except Exception as e:
            raise_harness_error(
                operation="CoordinateSystem.transform_point",
                what_happened="Failed to transform the point into global coordinates.",
                possible_causes=[
                    "The point is not a valid finite 3D vector.",
                    "The coordinate system axes are invalid or inconsistent.",
                ],
                how_to_fix=[
                    "Pass a finite 3D point.",
                    "Validate the coordinate system before transforming points.",
                ],
                error=e,
            )

    def transform_vector(self, vector: np.ndarray) -> np.ndarray:
        try:
            v = np.array(vector, dtype=float)
            if v.shape != (3,):
                raise_harness_error(
                    operation="CoordinateSystem.transform_vector",
                    what_happened="The vector could not be interpreted as a 3D direction.",
                    possible_causes=[
                        "The input does not contain exactly three numeric components.",
                        "The input was passed as a malformed nested structure.",
                    ],
                    how_to_fix=[
                        "Pass the vector as a 3-element tuple, list, or NumPy array.",
                        "Validate the vector shape before calling transform_vector().",
                    ],
                    technical_details=f"vector_shape={v.shape}",
                )
            if not np.all(np.isfinite(v)):
                raise_harness_error(
                    operation="CoordinateSystem.transform_vector",
                    what_happened="The vector contains non-finite numeric values.",
                    possible_causes=[
                        "A previous computation produced NaN or infinity.",
                        "The direction vector was derived from invalid geometry.",
                    ],
                    how_to_fix=[
                        "Inspect the upstream direction calculation.",
                        "Ensure all vector components are finite numbers before calling this API.",
                    ],
                    technical_details=f"vector={tuple(v.tolist())}",
                )
            return v[0] * self.x_axis + v[1] * self.y_axis + v[2] * self.z_axis
        except Exception as e:
            raise_harness_error(
                operation="CoordinateSystem.transform_vector",
                what_happened="Failed to transform the vector into global coordinates.",
                possible_causes=[
                    "The vector is not a valid finite 3D direction.",
                    "The coordinate system axes are invalid or inconsistent.",
                ],
                how_to_fix=[
                    "Pass a finite 3D direction vector.",
                    "Validate the coordinate system before transforming vectors.",
                ],
                error=e,
            )

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"CoordinateSystem(origin={tuple(self.origin)}, x_axis={tuple(self.x_axis)}, y_axis={tuple(self.y_axis)})"

    def _format_string(self, indent: int = 0) -> str:
        spaces = "  " * indent
        result = []
        result.append(f"{spaces}CoordinateSystem:")
        result.append(f"{spaces}  origin: [{self.origin[0]:.3f}, {self.origin[1]:.3f}, {self.origin[2]:.3f}]")
        result.append(f"{spaces}  x_axis: [{self.x_axis[0]:.3f}, {self.x_axis[1]:.3f}, {self.x_axis[2]:.3f}]")
        result.append(f"{spaces}  y_axis: [{self.y_axis[0]:.3f}, {self.y_axis[1]:.3f}, {self.y_axis[2]:.3f}]")
        result.append(f"{spaces}  z_axis: [{self.z_axis[0]:.3f}, {self.z_axis[1]:.3f}, {self.z_axis[2]:.3f}]")
        return "\n".join(result)


WORLD_CS = CoordinateSystem()


class SimpleWorkplane:
    """Workplane context manager defining a local coordinate system."""

    def __init__(
        self,
        origin: Tuple[float, float, float] = (0, 0, 0),
        normal: Tuple[float, float, float] = (0, 0, 1),
        x_dir: Tuple[float, float, float] = (1, 0, 0),
    ):
        current_cs = get_current_cs()
        global_origin = current_cs.transform_point(np.array(origin))
        global_x_dir = current_cs.transform_vector(np.array(x_dir))
        global_normal = current_cs.transform_vector(np.array(normal))
        global_normal = global_normal / np.linalg.norm(global_normal)
        global_y_dir = np.cross(global_normal, global_x_dir)
        y_norm = np.linalg.norm(global_y_dir)
        if y_norm < 1e-10:
            temp_x = np.array([1, 0, 0]) if abs(global_normal[0]) < 0.9 else np.array([0, 1, 0])
            global_y_dir = np.cross(global_normal, temp_x)
            global_y_dir = global_y_dir / np.linalg.norm(global_y_dir)
            global_x_dir = np.cross(global_y_dir, global_normal)
            global_x_dir = global_x_dir / np.linalg.norm(global_x_dir)
        else:
            global_y_dir = global_y_dir / y_norm
            global_x_dir = np.cross(global_y_dir, global_normal)
            global_x_dir = global_x_dir / np.linalg.norm(global_x_dir)
        self.cs = CoordinateSystem(tuple(global_origin), tuple(global_x_dir), tuple(global_y_dir))
        self._token: Optional[Token[Tuple[CoordinateSystem, ...]]] = None

    def __enter__(self):
        stack = _current_cs_stack.get()
        self._token = _current_cs_stack.set((*stack, self.cs))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._token is not None:
            _current_cs_stack.reset(self._token)
            self._token = None

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"SimpleWorkplane(origin={tuple(self.cs.origin)}, normal={tuple(self.cs.z_axis)})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = True) -> str:
        spaces = "  " * indent
        result = [f"{spaces}SimpleWorkplane:"]
        if show_coordinate_system:
            result.append(f"{spaces}  coordinate_system:")
            result.append(self.cs._format_string(indent + 2))
        return "\n".join(result)


_current_cs_stack: ContextVar[Tuple[CoordinateSystem, ...]] = ContextVar(
    "simplecadapi_current_cs_stack", default=(WORLD_CS,)
)


def get_current_cs() -> CoordinateSystem:
    return _current_cs_stack.get()[-1]


def _coordinate_system_from_context(context: Dict[str, Any]) -> CoordinateSystem:
    origin = context.get("origin", (0.0, 0.0, 0.0))
    x_axis = context.get("x_axis", (1.0, 0.0, 0.0))
    y_axis = context.get("y_axis", (0.0, 1.0, 0.0))
    return CoordinateSystem(
        cast(Tuple[float, float, float], tuple(float(v) for v in origin)),
        cast(Tuple[float, float, float], tuple(float(v) for v in x_axis)),
        cast(Tuple[float, float, float], tuple(float(v) for v in y_axis)),
    )


@contextmanager
def use_coordinate_system(
    cs_or_context: Union[CoordinateSystem, Dict[str, Any]]
):
    cs = (
        cs_or_context
        if isinstance(cs_or_context, CoordinateSystem)
        else _coordinate_system_from_context(cs_or_context)
    )
    stack = _current_cs_stack.get()
    token = _current_cs_stack.set((*stack, cs))
    try:
        yield
    finally:
        _current_cs_stack.reset(token)


class TaggedMixin:
    """Tag mixin that provides tagging support for geometry objects."""

    def __init__(self, entity: Optional[_TopoEntity] = None):
        self._entity = entity
        if entity is None:
            self._tags: Set[str] = set()
            self._metadata: Dict[str, Any] = {}
            self._runtime: Dict[str, Any] = {}
        else:
            self._tags = entity.tags
            self._metadata = entity.metadata
            self._runtime = entity.runtime
            entity.wrappers.append(self)

    @property
    def topo_id(self) -> str:
        entity = getattr(self, "_entity", None)
        if entity is not None:
            return entity.topo_id
        return f"object_{id(self)}"

    def same_topology(self, other: Any) -> bool:
        return getattr(other, "topo_id", None) == self.topo_id

    def _add_tag(self, tag: str) -> None:
        if not isinstance(tag, str):
            raise TypeError("标签必须是字符串类型")
        tag = normalize_tag(tag, strict=True)
        self._tags.add(tag)

    def _apply_tag(
        self, tag: str, *, normalize: bool = True, propagate: Optional[bool] = None
    ) -> None:
        if normalize:
            tag = normalize_tag(tag, strict=True)
        self._tags.add(tag)
        if propagate is None:
            propagate = DEFAULT_TAG_POLICY.should_propagate(tag)
        if propagate:
            self._propagate_tag_down(tag)

    def _propagate_tag_down(self, tag: str) -> None:
        if not isinstance(self, TopoMixein):
            return
        try:
            children = self.get_children()
        except Exception:
            return
        for child in children:
            if isinstance(child, TaggedMixin):
                child._tags.add(tag)
                child._propagate_tag_down(tag)

    def _remove_tag(self, tag: str) -> None:
        self._tags.discard(tag)

    def _has_tag(self, tag: str) -> bool:
        return tag in self._tags

    def _list_tags(self) -> list[str]:
        return sorted(self._tags)

    def set_metadata(self, key: str, value: Any) -> None:
        self._metadata[key] = value

    def get_metadata(self, key: str, default: Any = None) -> Any:
        return self._metadata.get(key, default)

    def _set_runtime(self, key: str, value: Any) -> None:
        self._runtime[key] = value

    def _get_runtime(self, key: str, default: Any = None) -> Any:
        return self._runtime.get(key, default)

    def _format_tags_and_metadata(self, indent: int = 0) -> str:
        spaces = "  " * indent
        result = []
        if self._tags:
            result.append(f"{spaces}tags: [{', '.join(sorted(self._tags))}]")
        if self._metadata:
            result.append(f"{spaces}metadata:")
            for key, value in sorted(self._metadata.items()):
                result.append(f"{spaces}  {key}: {value}")
        return "\n".join(result)


class TopoMixein:
    """Topology management mixin."""

    def __init__(self, level: int, self_shape_ref: "AnyShape") -> None:
        self.level: int = level
        self.self_shape_ref: AnyShape = self_shape_ref
        self.children: List[AnyShape] = []
        self.parent: Optional[AnyShape] = None
        self.parents: List[AnyShape] = []

    def set_parent(self, parent: "AnyShape") -> None:
        self.parent = parent
        if parent not in self.parents:
            self.parents.append(parent)

    def add_parent(self, parent: "AnyShape") -> None:
        self.set_parent(parent)

    def add_child(self, child: "AnyShape") -> None:
        if child not in self.children:
            self.children.append(child)
            child.set_parent(self.self_shape_ref)

    def get_children(self) -> List["AnyShape"]:
        return self.children

    def get_parent(self) -> Optional["AnyShape"]:
        return self.parent

    def get_parents(self) -> List["AnyShape"]:
        return list(self.parents)


def _record_indexed_topology_selection(source: Any, selected_shapes: Iterable[Any]) -> None:
    shapes = [shape for shape in selected_shapes if isinstance(shape, TaggedMixin)]
    if not shapes:
        return
    try:
        from .operations import _ensure_geo_selection_node_ids

        _ensure_geo_selection_node_ids(cast(AnyShape, source), cast(List[AnyShape], shapes))
    except Exception:
        return


class _TopologySelectionList(list):
    def __init__(self, source: Any, target_kind: str, items: Iterable[Any]) -> None:
        super().__init__(items)
        self._source = source
        self._target_kind = target_kind

    def __getitem__(self, index: Any) -> Any:
        selected = super().__getitem__(index)
        if isinstance(index, slice):
            _record_indexed_topology_selection(self._source, selected)
            return selected
        _record_indexed_topology_selection(self._source, [selected])
        return selected


def _selection_list(source: Any, target_kind: str, items: Iterable[Any]) -> List[Any]:
    return cast(List[Any], _TopologySelectionList(source, target_kind, items))


class Vertex(TaggedMixin, TopoMixein):
    """OCP-native vertex wrapper with tag support."""

    def __init__(self, vertex: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_vertex(vertex)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("vertex", self.wrapped))
            TopoMixein.__init__(self, level=0, self_shape_ref=self)
        except Exception as e:
            raise ValueError(f"初始化顶点失败: {e}. 请检查输入的顶点对象是否有效。")

    def get_coordinates(self) -> Tuple[float, float, float]:
        try:
            return vertex_point(self.wrapped)
        except Exception as e:
            raise ValueError(f"获取顶点坐标失败: {e}")

    def get_incident_edges(self) -> List["Edge"]:
        edges: List[Edge] = []
        for edge_id in getattr(self._entity, "incident_edge_ids", set()):
            for wrapper in self._topology_cache.wrappers_for(edge_id):
                if isinstance(wrapper, Edge) and wrapper.topo_id == edge_id:
                    edges.append(wrapper)
                    break
        return edges

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"Vertex(coordinates={self.get_coordinates()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = False) -> str:
        spaces = "  " * indent
        coords = self.get_coordinates()
        result = [f"{spaces}Vertex:", f"{spaces}  coordinates: [{coords[0]:.3f}, {coords[1]:.3f}, {coords[2]:.3f}]"]
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


class Edge(TaggedMixin, TopoMixein):
    """OCP-native edge wrapper with tag support."""

    def __init__(self, edge: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_edge(edge)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("edge", self.wrapped))
            TopoMixein.__init__(self, level=1, self_shape_ref=self)
            for vertex in vertices_of(self.wrapped):
                child_vertex = Vertex(vertex, cache=self._topology_cache)
                self.add_child(child_vertex)
                child_vertex._entity.incident_edge_ids.add(self.topo_id)
        except Exception as e:
            raise ValueError(f"初始化边失败: {e}. 请检查输入的边对象是否有效。")

    def get_length(self) -> float:
        try:
            return float(linear_length(self.wrapped))
        except Exception as e:
            raise ValueError(f"获取边长度失败: {e}")

    def get_start_vertex(self) -> Vertex:
        try:
            if len(self.get_children()) < 1:
                raise ValueError("边没有顶点")
            return cast(Vertex, self.get_children()[0])
        except Exception as e:
            raise ValueError(f"获取起始顶点失败: {e}")

    def get_end_vertex(self) -> Vertex:
        try:
            if len(self.get_children()) < 2:
                raise ValueError("边没有足够的顶点")
            return cast(Vertex, self.get_children()[-1])
        except Exception as e:
            raise ValueError(f"获取结束顶点失败: {e}")

    def get_center(self) -> Vec3:
        return center_of_mass(self.wrapped)

    def get_incident_faces(self) -> List["Face"]:
        faces: List[Face] = []
        for face_id in getattr(self._entity, "incident_face_ids", set()):
            for wrapper in self._topology_cache.wrappers_for(face_id):
                if isinstance(wrapper, Face) and wrapper.topo_id == face_id:
                    faces.append(wrapper)
                    break
        return faces

    def get_vertices(self, index: Optional[int] = None) -> Union[List[Vertex], Vertex]:
        try:
            vertices = [
                child for child in self.get_children() if isinstance(child, Vertex)
            ]
            result = cast(List[Vertex], _selection_list(self, "vertex", vertices))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取顶点失败: {e}")

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        length = self.get_length()
        try:
            part1 = f"from: {self.get_start_vertex().get_coordinates()}, to: {self.get_end_vertex().get_coordinates()}"
        except Exception:
            part1 = "from: [unable to retrieve], to: [unable to retrieve], usually this is a closed edge"
        return f"Edge({part1}, length={length:.3f}, tags={self._list_tags()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = False) -> str:
        spaces = "  " * indent
        result = [f"{spaces}Edge:", f"{spaces}  length: {self.get_length():.3f}"]
        try:
            result.append(f"{spaces}  vertices:")
            result.append(f"{spaces}    start: {self.get_start_vertex().get_coordinates()}")
            result.append(f"{spaces}    end: {self.get_end_vertex().get_coordinates()}")
        except Exception:
            result.append(f"{spaces}  vertices: [unable to retrieve, usually a closed edge]")
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


class Wire(TaggedMixin, TopoMixein):
    """OCP-native wire wrapper with tag support."""

    def __init__(self, wire: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_wire(wire)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("wire", self.wrapped))
            TopoMixein.__init__(self, level=2, self_shape_ref=self)
            for edge in edges_of(self.wrapped):
                self.add_child(Edge(edge, cache=self._topology_cache))
            self._tag_edges()
        except Exception as e:
            raise ValueError(f"初始化线失败: {e}. 请检查输入的线对象是否有效。")

    def get_edges(self, index: Optional[int] = None) -> Union[List[Edge], Edge]:
        try:
            result = cast(List[Edge], _selection_list(self, "edge", self.get_children()))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取边失败: {e}")

    def is_closed(self) -> bool:
        try:
            return bool(is_wire_closed(self.wrapped))
        except Exception as e:
            raise ValueError(f"检查线闭合性失败: {e}")

    def _tag_edges(self) -> None:
        policy = DEFAULT_TAG_POLICY
        for i, edge in enumerate(self.get_edges()):
            for tag in self._list_tags():
                if policy.should_propagate(tag):
                    edge._add_tag(tag)
            edge._apply_tag("edge.boundary", propagate=False)
            geo = dict(edge.get_metadata("geo", {}))
            geo["edge_index"] = i
            edge.set_metadata("geo", geo)

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"Wire(edge_count={len(self.get_edges())}, closed={self.is_closed()}, tags={self._list_tags()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = False) -> str:
        spaces = "  " * indent
        edges = self.get_edges()
        result = [f"{spaces}Wire:", f"{spaces}  edge_count: {len(edges)}", f"{spaces}  closed: {self.is_closed()}"]
        if edges:
            result.append(f"{spaces}  edges:")
            for i, edge in enumerate(edges):
                result.append(f"{spaces}    edge_{i}:")
                result.append(edge._format_string(indent + 3, False))
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


class Face(TaggedMixin, TopoMixein):
    """OCP-native face wrapper with tag support."""

    def __init__(self, face: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_face(face)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("face", self.wrapped))
            TopoMixein.__init__(self, level=3, self_shape_ref=self)
            outer_wire = Wire(outer_wire_of(self.wrapped), cache=self._topology_cache)
            outer_wire._apply_tag("wire.outer", propagate=False)
            self.add_child(outer_wire)
            for edge in outer_wire.get_edges():
                edge._entity.incident_face_ids.add(self.topo_id)
            for wire in inner_wires_of(self.wrapped):
                inner = Wire(wire, cache=self._topology_cache)
                inner._apply_tag("wire.inner", propagate=False)
                self.add_child(inner)
                for edge in inner.get_edges():
                    edge._entity.incident_face_ids.add(self.topo_id)
        except Exception as e:
            raise ValueError(f"初始化面失败: {e}. 请检查输入的面对象是否有效。")

    def get_area(self) -> float:
        try:
            return float(surface_area(self.wrapped))
        except Exception as e:
            raise ValueError(f"获取面积失败: {e}")

    def get_normal_at(self, u: float = 0.5, v: float = 0.5) -> Vec3:
        try:
            return face_normal_at(self.wrapped, u, v)
        except Exception as e:
            raise ValueError(f"获取法向量失败: {e}")

    def _tag_wires(self) -> None:
        policy = DEFAULT_TAG_POLICY
        outer_wire = self.get_outer_wire()
        for tag in self._list_tags():
            if policy.should_propagate(tag):
                outer_wire._add_tag(tag)
        outer_wire._apply_tag("wire.outer", propagate=False)
        outer_wire._tag_edges()
        for i, inner in enumerate(self.get_inner_wires()):
            for tag in self._list_tags():
                if policy.should_propagate(tag):
                    inner._add_tag(tag)
            inner._apply_tag("wire.inner", propagate=False)
            geo = dict(inner.get_metadata("geo", {}))
            geo["inner_wire_index"] = i
            inner.set_metadata("geo", geo)
            inner._tag_edges()

    def get_outer_wire(self) -> Wire:
        try:
            return [w for w in cast(List[Wire], self.get_children()) if w.is_closed() and w._has_tag("wire.outer")][0]
        except Exception as e:
            raise ValueError(f"获取外边界线失败: {e}")

    def get_wires(self, index: Optional[int] = None) -> Union[List[Wire], Wire]:
        try:
            wires = [child for child in self.get_children() if isinstance(child, Wire)]
            result = cast(List[Wire], _selection_list(self, "wire", wires))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取边界线失败: {e}")

    def get_inner_wires(self, index: Optional[int] = None) -> Union[List[Wire], Wire]:
        try:
            wires = [
                w
                for w in cast(List[Wire], self.get_children())
                if w.is_closed() and w._has_tag("wire.inner")
            ]
            result = cast(List[Wire], _selection_list(self, "wire", wires))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取内边界线失败: {e}")

    def get_center(self) -> Vec3:
        return center_of_mass(self.wrapped)

    def get_edges(self, index: Optional[int] = None) -> Union[List[Edge], Edge]:
        edges: List[Edge] = []
        edges.extend(self.get_outer_wire().get_edges())
        for inner in self.get_inner_wires():
            edges.extend(inner.get_edges())
        result = cast(List[Edge], _selection_list(self, "edge", edges))
        if index is None:
            return result
        return result[index]

    def get_adjacent_faces(self) -> List["Face"]:
        adjacent: Dict[str, Face] = {}
        for edge in self.get_edges():
            for face in edge.get_incident_faces():
                if face.topo_id != self.topo_id:
                    adjacent.setdefault(face.topo_id, face)
        return list(adjacent.values())

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"Face(area={self.get_area():.3f}, normal={self.get_normal_at()}, center={self.get_center()}, tags={self._list_tags()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = False) -> str:
        spaces = "  " * indent
        result = [f"{spaces}Face:", f"{spaces}  area: {self.get_area():.3f}, center: {self.get_center()}"]
        try:
            normal = self.get_normal_at()
            result.append(f"{spaces}  normal: [{normal.x:.3f}, {normal.y:.3f}, {normal.z:.3f}]")
        except Exception:
            result.append(f"{spaces}  normal: [unable to retrieve]")
        try:
            result.append(f"{spaces}  outer_wire:")
            result.append(self.get_outer_wire()._format_string(indent + 2, False))
        except Exception:
            result.append(f"{spaces}  outer_wire: [unable to retrieve]")
        try:
            for inner in self.get_inner_wires():
                result.append(f"{spaces}  inner_wire:")
                result.append(inner._format_string(indent + 2, False))
        except Exception:
            result.append(f"{spaces}  inner_wires: [unable to retrieve]")
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


class Solid(TaggedMixin, TopoMixein):
    """OCP-native solid wrapper with tag support."""

    def __init__(self, solid: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_solid(solid)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("solid", self.wrapped))
            TopoMixein.__init__(self, level=4, self_shape_ref=self)
            for face in faces_of(self.wrapped):
                self.add_child(Face(face, cache=self._topology_cache))
            try:
                from ._mesh import attach_default_mesh

                attach_default_mesh(self)
            except Exception as mesh_error:
                self._set_runtime("mesh.error", str(mesh_error))
        except Exception as e:
            raise ValueError(f"初始化实体失败: {e}. 请检查输入的实体对象是否有效。")

    def get_volume(self) -> float:
        try:
            return float(volume(self.wrapped))
        except Exception as e:
            raise ValueError(f"获取体积失败: {e}")

    def get_faces(self, index: Optional[int] = None) -> Union[List[Face], Face]:
        try:
            faces = [
                f for f in cast(List[Face], self.get_children()) if isinstance(f, Face)
            ]
            result = cast(List[Face], _selection_list(self, "face", faces))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取面失败: {e}")

    def get_edges(self, index: Optional[int] = None) -> Union[List[Edge], Edge]:
        try:
            unique: Dict[str, Edge] = {}
            for face in self.get_faces():
                for edge in face.get_edges():
                    unique.setdefault(edge.topo_id, edge)
            result = cast(List[Edge], _selection_list(self, "edge", unique.values()))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取边失败: {e}")

    def get_edge_occurrences(self, index: Optional[int] = None) -> Union[List[Edge], Edge]:
        try:
            edges: List[Edge] = []
            for face in self.get_faces():
                edges.extend(face.get_edges())
            result = cast(List[Edge], _selection_list(self, "edge", edges))
            if index is None:
                return result
            return result[index]
        except Exception as e:
            raise ValueError(f"获取边实例列表失败: {e}")

    def auto_tag_faces(self, geometry_type: str = "unknown") -> None:
        try:
            faces = self.get_faces()
            if geometry_type == "box" and len(faces) == 6:
                self._auto_tag_box_faces(faces)
            elif geometry_type == "cylinder" and len(faces) == 3:
                self._auto_tag_cylinder_faces(faces)
            elif geometry_type == "sphere" and len(faces) == 1:
                self._tag_face(next(iter(faces)), "surface")
            else:
                for i, face in enumerate(faces):
                    self._tag_face(face, f"face_{i}")
        except Exception as e:
            raise ValueError(f"自动标记面失败: {e}")

    def _auto_tag_box_faces(self, faces: List[Face]) -> None:
        try:
            for i, face in enumerate(faces):
                normal = face.get_normal_at()
                if abs(normal.z) > 0.9:
                    tag = "top" if normal.z > 0 else "bottom"
                elif abs(normal.y) > 0.9:
                    tag = "front" if normal.y > 0 else "back"
                elif abs(normal.x) > 0.9:
                    tag = "right" if normal.x > 0 else "left"
                else:
                    tag = f"face_{i}"
                self._tag_face(face, tag)
        except Exception as e:
            print(f"警告: 自动标记立方体面失败: {e}")

    def _auto_tag_cylinder_faces(self, faces: List[Face]) -> None:
        try:
            from OCP.BRepAdaptor import BRepAdaptor_Surface
            from OCP.GeomAbs import GeomAbs_Plane

            plane_faces = []
            side_faces = []
            for face in faces:
                surface_type = BRepAdaptor_Surface(face.wrapped).GetType()
                if surface_type == GeomAbs_Plane:
                    plane_faces.append(face)
                else:
                    side_faces.append(face)
            if len(plane_faces) != 2:
                raise ValueError(f"预期找到2个平面面，但找到了 {len(plane_faces)} 个")
            centers = [face.get_center() for face in plane_faces]
            spans = [
                abs(centers[1].x - centers[0].x),
                abs(centers[1].y - centers[0].y),
                abs(centers[1].z - centers[0].z),
            ]
            axis_index = max(range(3), key=lambda index: spans[index])
            plane_faces.sort(
                key=lambda face: (
                    face.get_center().x,
                    face.get_center().y,
                    face.get_center().z,
                )[axis_index]
            )
            bottom_face, top_face = plane_faces
            self._tag_face(bottom_face, "bottom")
            self._tag_face(top_face, "top")
            for face in side_faces:
                self._tag_face(face, "side")
        except Exception as e:
            print(f"警告: 自动标记圆柱体面失败: {e}")

    def _tag_face(self, face: Face, tag: str) -> None:
        face._apply_tag(f"face.{tag}", propagate=False)
        face._tag_wires()

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"Solid(volume={self.get_volume():.3f}, faces={len(self.get_faces())}, tags={self._list_tags()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = True) -> str:
        spaces = "  " * indent
        faces = self.get_faces()
        edges = self.get_edges()
        result = [f"{spaces}Solid:", f"{spaces}  volume: {self.get_volume():.3f}", f"{spaces}  face_count: {len(faces)}", f"{spaces}  edge_count: {len(edges)}"]
        if show_coordinate_system:
            current_cs = get_current_cs()
            if current_cs != WORLD_CS:
                result.append(f"{spaces}  coordinate_system:")
                result.append(current_cs._format_string(indent + 2))
        if faces:
            result.append(f"{spaces}  faces:")
            for i, face in enumerate(faces):
                result.append(f"{spaces}    face_{i}:")
                result.append(face._format_string(indent + 3, False))
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


class Compound(TaggedMixin, TopoMixein):
    """OCP-native compound wrapper for explicit multi-shape projections."""

    def __init__(self, compound: Any, cache: Optional[_TopologyEntityCache] = None):
        try:
            self.wrapped = as_compound(compound)
            self._topology_cache = cache or _TopologyEntityCache()
            TaggedMixin.__init__(self, self._topology_cache.get("compound", self.wrapped))
            TopoMixein.__init__(self, level=5, self_shape_ref=self)
            for solid in solids_of(self.wrapped):
                self.add_child(Solid(solid, cache=self._topology_cache))
        except Exception as e:
            raise ValueError(f"初始化组合体失败: {e}. 请检查输入的组合体对象是否有效。")

    def get_solids(self, index: Optional[int] = None) -> Union[List[Solid], Solid]:
        try:
            solids = [
                child for child in self.get_children() if isinstance(child, Solid)
            ]
            if index is None:
                return solids
            return solids[index]
        except Exception as e:
            raise ValueError(f"获取实体列表失败: {e}")

    def get_faces(self, index: Optional[int] = None) -> Union[List[Face], Face]:
        try:
            faces: List[Face] = []
            for solid in self.get_solids():
                faces.extend(cast(Solid, solid).get_faces())
            if index is None:
                return faces
            return faces[index]
        except Exception as e:
            raise ValueError(f"获取面失败: {e}")

    def get_edges(self, index: Optional[int] = None) -> Union[List[Edge], Edge]:
        try:
            unique: Dict[str, Edge] = {}
            for face in self.get_faces():
                for edge in face.get_edges():
                    unique.setdefault(edge.topo_id, edge)
            edges = list(unique.values())
            if index is None:
                return edges
            return edges[index]
        except Exception as e:
            raise ValueError(f"获取边失败: {e}")

    def get_volume(self) -> float:
        return sum(float(solid.get_volume()) for solid in self.get_solids())

    def __str__(self) -> str:
        return self._format_string(indent=0)

    def __repr__(self) -> str:
        return f"Compound(solids={len(self.get_solids())}, volume={self.get_volume():.3f}, tags={self._list_tags()})"

    def _format_string(self, indent: int = 0, show_coordinate_system: bool = True) -> str:
        spaces = "  " * indent
        solids = cast(List[Solid], self.get_solids())
        result = [
            f"{spaces}Compound:",
            f"{spaces}  solid_count: {len(solids)}",
            f"{spaces}  volume: {self.get_volume():.3f}",
        ]
        tags_metadata = self._format_tags_and_metadata(indent + 1)
        if tags_metadata:
            result.append(tags_metadata)
        return "\n".join(result)


AnyShape = Union[Vertex, Edge, Wire, Face, Solid, Compound]
