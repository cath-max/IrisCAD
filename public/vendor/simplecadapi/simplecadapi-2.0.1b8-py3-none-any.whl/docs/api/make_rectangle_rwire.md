# make_rectangle_rwire

## API Definition

```python
def make_rectangle_rwire(width: ScalarLike, height: ScalarLike, center: Tuple[ScalarLike, ScalarLike, ScalarLike] = (0, 0, 0), normal: Tuple[ScalarLike, ScalarLike, ScalarLike] = (0, 0, 1)) -> Wire
```

*Source: operations.py*

## Import Surface

- top-level: `from simplecadapi import make_rectangle_rwire`

## Description

Create a rectangular wire.

## Usage

Create a closed rectangular outline for lofts, sweeps, and profile-based operations.
