# make_spur_rack_rsolid

## API Definition

```python
def make_spur_rack_rsolid(module: float, n_teeth: int = 10, pressure_angle: float = 20.0, rack_height: float = 6.0) -> Solid
```

*Source: std/gear.py*

## Import Surface

- standard library: `import simplecadapi as scad` then `scad.std.gear.make_spur_rack_rsolid(...)`; direct submodule import: `from simplecadapi.std.gear import make_spur_rack_rsolid`

## Description

Create a straight-tooth rack.

## Parameters

### module

- **Type**: `float`
- **Description**: Gear module in mm (tooth pitch = pi * module).

### n_teeth

- **Type**: `int, default 10`
- **Description**: Number of teeth along the rack.

### pressure_angle

- **Type**: `float, default 20`
- **Description**: Pressure angle in degrees.

### rack_height

- **Type**: `float, default 6.0`
- **Description**: Rack thickness along Z in mm.
