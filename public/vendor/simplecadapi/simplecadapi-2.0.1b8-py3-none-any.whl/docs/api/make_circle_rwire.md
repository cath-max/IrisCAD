# make_circle_rwire

## API Definition

```python
def make_circle_rwire(center: Tuple[float, float, float], radius: ScalarLike, normal: Tuple[float, float, float] = (0, 0, 1)) -> Wire
```

*Source: operations.py*

## Import Surface

- top-level: `from simplecadapi import make_circle_rwire`

## Description

Create a circular wire.

## Usage

Create a closed circular outline for loft sections, revolved profiles, and circular paths.
