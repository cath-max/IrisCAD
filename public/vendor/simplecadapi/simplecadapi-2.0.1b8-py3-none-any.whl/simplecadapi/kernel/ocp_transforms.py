"""Thin OCP-native transform helpers for public geometry wrappers."""

from __future__ import annotations

import math
from typing import Tuple

from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.TopAbs import (
    TopAbs_COMPOUND,
    TopAbs_EDGE,
    TopAbs_FACE,
    TopAbs_SOLID,
    TopAbs_VERTEX,
    TopAbs_WIRE,
)
from OCP.gp import gp_Ax1, gp_Ax2, gp_Dir, gp_Pnt, gp_Trsf, gp_Vec

from ..core import AnyShape, Compound, Edge, Face, Solid, Vertex, Wire
from ._ocp_compat import (
    TopoDS_Compound_s,
    TopoDS_Edge_s,
    TopoDS_Face_s,
    TopoDS_Solid_s,
    TopoDS_Vertex_s,
    TopoDS_Wire_s,
)


def _shape_from_transformed(shape: AnyShape, transformed) -> AnyShape:
    shape_type = transformed.ShapeType()
    if shape_type == TopAbs_VERTEX:
        return Vertex(TopoDS_Vertex_s(transformed))
    if shape_type == TopAbs_EDGE:
        return Edge(TopoDS_Edge_s(transformed))
    if shape_type == TopAbs_WIRE:
        return Wire(TopoDS_Wire_s(transformed))
    if shape_type == TopAbs_FACE:
        return Face(TopoDS_Face_s(transformed))
    if shape_type == TopAbs_SOLID:
        return Solid(TopoDS_Solid_s(transformed))
    if shape_type == TopAbs_COMPOUND:
        return Compound(TopoDS_Compound_s(transformed))
    raise ValueError(f"Unsupported transformed shape type: {shape_type}")


def apply_transform(shape: AnyShape, trsf: gp_Trsf) -> AnyShape:
    xform = BRepBuilderAPI_Transform(shape.wrapped, trsf, True)
    xform.Build()
    if not xform.IsDone():
        raise ValueError("OCP transform build failed")
    return _shape_from_transformed(shape, xform.Shape())


def translate_shape_ocp(
    shape: AnyShape, vector: Tuple[float, float, float]
) -> AnyShape:
    trsf = gp_Trsf()
    trsf.SetTranslation(gp_Vec(float(vector[0]), float(vector[1]), float(vector[2])))
    return apply_transform(shape, trsf)


def rotate_shape_ocp(
    shape: AnyShape,
    angle_degrees: float,
    axis: Tuple[float, float, float],
    origin: Tuple[float, float, float],
) -> AnyShape:
    trsf = gp_Trsf()
    trsf.SetRotation(
        gp_Ax1(
            gp_Pnt(float(origin[0]), float(origin[1]), float(origin[2])),
            gp_Dir(float(axis[0]), float(axis[1]), float(axis[2])),
        ),
        math.radians(float(angle_degrees)),
    )
    return apply_transform(shape, trsf)


def mirror_shape_ocp(
    shape: AnyShape,
    plane_origin: Tuple[float, float, float],
    plane_normal: Tuple[float, float, float],
) -> AnyShape:
    trsf = gp_Trsf()
    trsf.SetMirror(
        gp_Ax2(
            gp_Pnt(
                float(plane_origin[0]), float(plane_origin[1]), float(plane_origin[2])
            ),
            gp_Dir(
                float(plane_normal[0]),
                float(plane_normal[1]),
                float(plane_normal[2]),
            ),
        )
    )
    return apply_transform(shape, trsf)


def place_shape_ocp(
    shape: AnyShape,
    origin: Tuple[float, float, float],
    x_axis: Tuple[float, float, float],
    y_axis: Tuple[float, float, float],
    z_axis: Tuple[float, float, float],
) -> AnyShape:
    trsf = gp_Trsf()
    trsf.SetValues(
        float(x_axis[0]),
        float(y_axis[0]),
        float(z_axis[0]),
        float(origin[0]),
        float(x_axis[1]),
        float(y_axis[1]),
        float(z_axis[1]),
        float(origin[1]),
        float(x_axis[2]),
        float(y_axis[2]),
        float(z_axis[2]),
        float(origin[2]),
    )
    return apply_transform(shape, trsf)
